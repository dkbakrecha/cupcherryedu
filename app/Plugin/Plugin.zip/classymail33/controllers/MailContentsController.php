<?php

class MailContentController extends ClassymailAppController {
    public $uses = array('Classymail.MailContent');

    public function index() {
        //...
        echo "Hello Mail";
    }
}